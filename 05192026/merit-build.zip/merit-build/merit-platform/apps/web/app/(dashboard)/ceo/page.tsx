// CEO Dashboard — Executive view
// Audience: Akbar daily
// Auth: Clerk-gated
// Refresh: revalidate every 5 minutes

import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";

export const revalidate = 300; // 5 minutes

async function getDashboardData() {
  // TODO: wire to actual data sources
  // - meritgiving-ops/state/global-status.json
  // - GitHub API (PRs)
  // - meritgiving-ops/strategy/risks.md (parsed)
  // - meritgiving-ops/state/current-gate.json
  // - PostHog, Stripe, Resend APIs

  return {
    status: "green" as const,
    runwayMonths: 14,
    currentGate: { number: 1, name: "Legal Foundation", week: 2, status: "in_progress" },
    decisions: [
      { id: "1", title: "Attorney choice for ToS review", priority: "high" as const },
      { id: "2", title: "Approve 2 PRs in review", priority: "medium" as const },
      { id: "3", title: "Advisor Leslie call at 2pm — prep notes", priority: "medium" as const },
    ],
    departments: [
      { name: "Product/Eng", status: "green" as const, update: "2 PRs in review" },
      { name: "Data/Research", status: "green" as const, update: "BMF refresh complete" },
      { name: "Growth/Comms", status: "green" as const, update: "Newsletter draft ready" },
      { name: "Operations", status: "green" as const, update: "0 incidents" },
      { name: "Finance", status: "yellow" as const, update: "CPA review of Q2 close pending" },
      { name: "Legal", status: "green" as const, update: "No filings due 30d" },
      { name: "Partnerships", status: "yellow" as const, update: "3 outreach awaiting reply" },
      { name: "Intelligence", status: "green" as const, update: "Brief delivered" },
      { name: "Strategy", status: "green" as const, update: "OKRs on track" },
      { name: "Nonprofit Success", status: "green" as const, update: "Inbox: 0, claims: 0 (P0)" },
    ],
    topRisks: [
      { id: "R-004", title: "Security breach exposing PII", status: "mitigating" as const },
      { id: "R-005", title: "Founder burnout", status: "monitoring" as const },
      { id: "R-007", title: "Auto-revocation handling policy", status: "open" as const },
    ],
    kpis: [
      { label: "Newsletter subs", value: 0, target: 500, direction: "neutral" as const },
      { label: "Credits secured", value: "$0", target: "$10K", direction: "neutral" as const },
      { label: "Monthly burn", value: "$8", target: "<$300", direction: "good" as const },
      { label: "Days to launch", value: 168, target: 168, direction: "neutral" as const },
    ],
  };
}

function StatusDot({ status }: { status: "green" | "yellow" | "red" }) {
  const colors = {
    green: "bg-emerald-500",
    yellow: "bg-amber-500",
    red: "bg-red-500",
  };
  return <span className={`inline-block w-2 h-2 rounded-full ${colors[status]}`} />;
}

export default async function CEODashboard() {
  const { userId } = await auth();
  if (!userId) redirect("/sign-in");

  const data = await getDashboardData();
  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-baseline justify-between border-b pb-4">
        <h1 className="text-2xl font-semibold">MERIT — CEO Dashboard</h1>
        <span className="text-sm text-gray-500">{today}</span>
      </div>

      {/* Status banner */}
      <div className="bg-gray-50 rounded-lg p-4 grid grid-cols-3 gap-4">
        <div className="flex items-center gap-2">
          <StatusDot status={data.status} />
          <span className="text-sm font-medium">All systems normal</span>
        </div>
        <div>
          <span className="text-xs text-gray-500 block">Runway</span>
          <span className="text-sm font-medium">{data.runwayMonths} months</span>
        </div>
        <div>
          <span className="text-xs text-gray-500 block">Current gate</span>
          <span className="text-sm font-medium">
            Gate {data.currentGate.number}: {data.currentGate.name} (Week {data.currentGate.week})
          </span>
        </div>
      </div>

      {/* Today's top 3 */}
      <section>
        <h2 className="text-lg font-semibold mb-3">Today's top 3 decisions</h2>
        <ul className="space-y-2">
          {data.decisions.map((d, i) => (
            <li key={d.id} className="flex items-center gap-3 p-3 bg-white border rounded-lg">
              <span className="text-gray-400 font-mono text-sm">{i + 1}.</span>
              <span className="flex-1">{d.title}</span>
              <span
                className={`text-xs px-2 py-0.5 rounded ${
                  d.priority === "high"
                    ? "bg-red-100 text-red-700"
                    : "bg-amber-100 text-amber-700"
                }`}
              >
                {d.priority}
              </span>
            </li>
          ))}
        </ul>
      </section>

      {/* Department status grid */}
      <section>
        <h2 className="text-lg font-semibold mb-3">Department status</h2>
        <div className="grid grid-cols-2 gap-3">
          {data.departments.map((d) => (
            <div key={d.name} className="flex items-center gap-3 p-3 bg-white border rounded-lg">
              <StatusDot status={d.status} />
              <div className="flex-1">
                <div className="text-sm font-medium">{d.name}</div>
                <div className="text-xs text-gray-500">{d.update}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Top risks */}
      <section>
        <h2 className="text-lg font-semibold mb-3">Top risks</h2>
        <ul className="space-y-2">
          {data.topRisks.map((r) => (
            <li key={r.id} className="flex items-center gap-3 p-3 bg-white border rounded-lg">
              <span className="text-xs font-mono text-gray-400">{r.id}</span>
              <span className="flex-1 text-sm">{r.title}</span>
              <span className="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-700">
                {r.status}
              </span>
            </li>
          ))}
        </ul>
      </section>

      {/* KPIs */}
      <section>
        <h2 className="text-lg font-semibold mb-3">KPI movement</h2>
        <div className="grid grid-cols-4 gap-3">
          {data.kpis.map((k) => (
            <div key={k.label} className="p-4 bg-white border rounded-lg">
              <div className="text-xs text-gray-500">{k.label}</div>
              <div className="text-xl font-semibold mt-1">{k.value}</div>
              <div className="text-xs text-gray-400 mt-1">target: {k.target}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
