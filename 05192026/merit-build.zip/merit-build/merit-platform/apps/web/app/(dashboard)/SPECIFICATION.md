# Dashboard System Specification

Three dashboards, three audiences, three update cadences. This doc tells eng-lead and Claude Code exactly what to build.

---

## Architecture

All three dashboards live in the same Next.js app at `apps/web/app/(dashboard)/`:

```
apps/web/app/(dashboard)/
├── layout.tsx           # Shared shell, navigation
├── ceo/page.tsx         # CEO dashboard (Clerk-gated)
├── ops/page.tsx         # Operations dashboard (Clerk-gated)
└── mission/page.tsx     # Public impact dashboard
```

**Data sources:**
- Neon Postgres (primary data)
- PostHog (product analytics)
- Stripe (tip jar)
- Sentry (errors)
- Better Stack (uptime)
- GitHub API (PRs, deploys)
- Markdown files in `meritgiving-ops/` (status, decisions, OKRs)

**Auth:**
- `/ceo` and `/ops`: Clerk-gated, single user (Akbar)
- `/mission`: public, no auth

**Server-side rendering:** All dashboards SSR with revalidate. No client-side data fetching for dashboard cards.

---

## Dashboard 1: `/ceo` — Executive view

**Audience:** Akbar daily
**Refresh:** Server-side, revalidate every 5 min
**Load time target:** < 2 seconds

### Sections (top to bottom)

**1. Status banner**
- Global health indicator (green/yellow/red)
- Runway in months (calculated from finance-lead data)
- This week's gate progress

**2. Today's top 3 decisions**
- Pulled from approval queue
- One-click approve/reject/needs-discussion
- Most recent first

**3. Department status grid**
- 10 cards, one per department
- Each shows: dept name, status indicator, top metric, one-line update
- Click to drill into `/dept/[name]`

**4. Top 3 risks**
- From risks.md, severity-ranked
- Show current mitigation status

**5. This week's gate**
- Current gate name + week number
- Pass criteria with checkboxes
- Critical path items

**6. KPI sparklines**
- Newsletter subs
- Credits balance
- Burn rate
- Inbox depth
- (Phase 1+) Claimed profiles

### Data sources per section

- Status banner: `meritgiving-ops/state/global-status.json` (updated by ops-lead nightly)
- Top 3 decisions: GitHub API (PRs) + Airtable Approvals
- Department status: each dept's `reports/latest.md` parsed
- Risks: `meritgiving-ops/strategy/risks.md` parsed
- Gate: `meritgiving-ops/state/current-gate.json`
- KPIs: PostHog API + Stripe API + Resend API + Postgres query

---

## Dashboard 2: `/ops` — Operational view

**Audience:** Akbar + Claude agents, multiple times daily
**Refresh:** Real-time (revalidate every 60 sec for critical metrics)
**Load time target:** < 2 seconds

### Sections

**1. Production health**
- Uptime over last 24h, 7d, 30d (from Better Stack)
- Error rate (from Sentry)
- P95 response time
- WAF events (from Cloudflare)

**2. Tip jar**
- This month tip revenue
- This week tip revenue
- Latest tip received
- Stripe payout status

**3. AI usage**
- Claude API spend this month (from Anthropic Console)
- Credits remaining per provider (AWS, GCP, Cloudflare, Microsoft, Anthropic)
- Days to credit exhaustion at current burn

**4. Inbox queues**
- Gmail unread counts per address (nonprofits@, support@, legal@, etc.)
- Approval queue depth
- Claim queue depth (Phase 1+)

**5. Workflow health**
- n8n execution status (last 24h)
- Last successful backup time
- Last successful BMF refresh
- Last successful badge recalculation

**6. Cost breakdown**
- Spend this month by category
- Burn rate projection
- Variance vs. plan

### Data sources per section

- Production health: Better Stack API + Sentry API + Cloudflare API
- Tip jar: Stripe API
- AI usage: Anthropic Console (manual entry until API access) + credits-tracker output
- Inbox: Gmail API via MCP
- Workflow: n8n API + filesystem (last-run timestamps)
- Cost: QBO export (eventually QBO MCP) + finance-lead reports

---

## Dashboard 3: `/mission` — Public impact view

**Audience:** Public (advisors, donors, nonprofits, press)
**Refresh:** Server-side, revalidate every 24h
**Load time target:** < 2 seconds
**SEO:** Indexed, social previews configured

### Sections

**1. Hero stats**
- EINs covered (always 1.8M+)
- Last data refresh date
- "All 501(c)(3)s. Equally."

**2. Phase 1+ stats**
- Profiles claimed (count)
- Active nonprofits (logged-in last 30d)
- Total tips collected (transparency)

**3. Phase 2+ stats**
- $ saved by nonprofits via GPO
- Active vendor partnerships
- Time saved (estimated)

**4. Build log**
- Last 5 weekly progress posts
- Link to full archive

**5. Recent decisions (anonymized)**
- Last 5 ADRs in plain-English summaries
- Link to full decision log

**6. Sector reports**
- All published reports with summaries
- Subscribe to next report CTA

**7. Mission lock principles**
- All 8 principles
- Link to operating agreement excerpt

### Data sources

All from `meritgiving-ops/` markdown files (parsed at build) + filtered Postgres queries (no sensitive data exposed).

---

## Implementation plan

**Phase 0 launch dashboard scope:**
- `/ceo` with sections 1, 2, 4, 5 (status, decisions, risks, gate)
- `/ops` with sections 1, 5 (production health, workflow health)
- `/mission` with sections 1, 4, 5, 6, 7 (hero, build log, decisions, reports, principles)

**Add through Phase 0:**
- Week 8: KPI sparklines on `/ceo`
- Week 12: Full `/ops` with tip jar + AI usage
- Week 16: Department status grid full
- Week 20: `/mission` final polish for launch

**Phase 1+ additions:**
- Claim queue on `/ops`
- Claimed profile stats on `/mission`
- Per-nonprofit dashboards (separate route)

## Technical decisions

- **No client-side data fetching for cards** — SSR with revalidate
- **No real-time WebSockets in Phase 0** — pull model is enough
- **No third-party analytics on `/mission`** — privacy-respecting (PostHog can opt out of cookies, that's fine for /ops and /ceo)
- **Charts via Recharts** (open source, React-native)
- **No graphics-heavy widgets** — text-first, scannable

## Performance targets

- LCP < 2.5s
- CLS < 0.1
- FID < 100ms
- Lighthouse score 95+

If any dashboard goes over budget, simplify before adding features. The dashboards are for utility, not show.
