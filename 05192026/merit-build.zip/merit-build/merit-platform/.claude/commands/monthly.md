# /monthly

**Monthly board-format review. Run 1st of each month.**

## When to use
- 1st business day of each month
- Generates the board-format summary sendable to advisors

## Process
1. Each department head agent generates monthly report
2. Finance-lead generates P&L, balance sheet, runway forecast
3. Strategy-lead generates OKR progress
4. Legal-lead generates risk register review
5. Intel-lead generates monthly state-of-the-org
6. Consolidate into single brief

## Output format

```markdown
# MERIT Monthly Review — [Month YYYY]

## EXECUTIVE SUMMARY (1 paragraph)
[Where we are, what changed, what's next]

## KPI DASHBOARD
[All key metrics, current value, vs target, direction]

## DEPARTMENT REPORTS
[10 sections, 1-page each]

## FINANCIAL POSITION
- Revenue this month: $X
- Burn this month: $Y
- Runway: M months
- Credits remaining: [breakdown]

## RISK REGISTER
- Top 3 risks this month
- Tripwires triggered: [any]
- New risks added: [count]

## OKRs PROGRESS
- O1: KR1 (X%), KR2 (Y%)...
- O2: ...
[Visual: green/yellow/red per KR]

## DECISIONS MADE
- ADR-XXX: [title]
[All ADRs published this month]

## NEXT MONTH PRIORITIES
- [3-5 items]

## STRATEGIC QUESTION FOR ADVISORS
[Question to bring to advisor circle this month]
```

## After running
- Save to `meritgiving-ops/briefings/monthly/YYYY-MM.md`
- Draft advisor email (separate, partnerships-lead)
- Update OKR scoring
- Flag any risk register changes for CEO
