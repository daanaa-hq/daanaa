# /weekly-allhands

**Monday morning all-hands brief — full department status.**

## When to use
- Every Monday morning during morning session
- Drives the week's priority setting

## Process
1. Read previous week's retro (Friday) at `meritgiving-ops/briefings/weekly/YYYY-WW-retro.md`
2. Activate intel-lead with weekly-synthesizer
3. Each department head agent generates 3-line status:
   - Wins from last week
   - Blockers for this week
   - Top priority this week
4. KPI dashboard snapshot
5. One strategic question for CEO judgment
6. Output saved to `meritgiving-ops/briefings/weekly/YYYY-WW.md`

## Output format

```markdown
# Week of [Monday Date] — All-Hands

## LAST WEEK
- Wins: [3-5 items]
- Problems: [2-3 items + proposed actions]
- Score: [Friday retro score]

## DEPARTMENT STATUS

| Dept | Last Week Win | This Week Focus | Blocker |
|------|---------------|------------------|---------|
| 01 Product/Eng | ... | ... | ... |
| 02 Data/Research | ... | ... | ... |
| ... (all 10) | ... | ... | ... |

## KPI MOVEMENT
- [Top 5 metrics, current value, direction, vs. target]

## GATE STATUS
- Current gate: [Gate N - Name, Week W]
- Status: 🟢/🟡/🔴
- Critical path items: [list]

## CEO DECISION NEEDED THIS WEEK
[Single strategic question or decision]

## WEEK PRIORITY
[The ONE thing that matters most this week]
```

## After running
- Update OKR tracker with current week scores
- Schedule advisor/sponsor calls per plan
- Confirm Wednesday user research call booked
