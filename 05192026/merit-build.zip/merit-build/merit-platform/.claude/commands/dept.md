# /dept [name]

**Full status of one department. Use for deep dives.**

## Usage
- `/dept finance` — full finance status
- `/dept data` — full data/research status
- etc.

## Process
1. Read the DEPT.md
2. Activate the department head agent
3. Pull recent reports from `meritgiving-ops/departments/[NN-name]/reports/`
4. Pull worker agent status
5. Generate comprehensive status

## Output format

```markdown
# Department: [Name] — Full Status

## MISSION
[From DEPT.md]

## KPIs (current vs. target)
- [KPI 1]: current X (target Y)
[All KPIs listed]

## WORKER AGENT STATUS
- [agent name]: status, last run, queue depth
[All workers listed]

## RECENT WINS
[Last 2 weeks]

## OPEN ISSUES
[Anything blocked, escalated, or stalled]

## UPCOMING WORK
[Next 2 weeks per OKRs]

## CROSS-DEPT DEPENDENCIES
- Inbound: [other depts depending on this one]
- Outbound: [this dept depending on others]

## RISK ITEMS
[Any open risks owned by this dept]

## CEO ATTENTION NEEDED
[Decisions or escalations pending]
```
