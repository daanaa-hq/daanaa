# /morning-brief

**Generates the CEO's daily morning brief — 5 min read max.**

## When to use
- Every morning at start of morning session (typically 6:00–6:30 AM)
- Or whenever CEO needs a current-state snapshot

## What it does

Pulls signals from all 10 departments via the intel-lead agent and synthesizes into the standard morning brief format.

## Process

1. Read `meritgiving-ops/state/last-session.md` for context
2. Activate intel-lead agent with task: "Generate today's morning brief"
3. intel-lead delegates to morning-briefer worker
4. morning-briefer gathers:
   - Overnight production status (Sentry, Better Stack)
   - Inbox depth (Gmail via MCP)
   - Credits status (manual tracker for now)
   - Calendar for today
   - Open approvals queued
   - Top 3 decisions needed
   - Sector signals from community-listener
   - This week's gate progress
5. Output saved to `meritgiving-ops/briefings/daily/YYYY-MM-DD.md`
6. Display in chat with key items highlighted

## Output format

```markdown
# Morning Brief — [Date]

## 🚨 URGENT (if any)
[Critical items requiring CEO action today]

## ⚡ TODAY'S TOP 3 DECISIONS
1. [Decision] — context, recommendation
2. [Decision] — context, recommendation
3. [Decision] — context, recommendation

## 🌙 OVERNIGHT
- Production: [status, any incidents]
- Inbox: [count, urgent items]
- Credits: [any updates from applications]
- Sector: [1-line if anything material]

## 📅 TODAY
- Calendar: [meetings, calls]
- Top focus: [priority for the day]
- Approvals queued: [count + summary]

## 🎯 THIS WEEK
- Gate progress: [Week N gate status]
- KPI movement: [top metrics, direction]

## 💡 WORTH KNOWING
- [Sector trend, useful link, optional]
```

## Tone
- Scannable, ≤500 words
- Each section ≤5 lines
- Lead with action, not context
- "So what?" embedded in every section
- Skip sections with nothing to report (don't pad)

## Escalations
If anything during generation surfaces an item flagged for escalation per any DEPT.md rules, raise immediately and run `/escalate` flow.
