# /log-decision

**Capture a decision as an ADR (Architecture Decision Record).**

## When to use
- After making any decision that future-you needs to remember
- When choosing between meaningful alternatives
- When committing to a path that's costly to reverse
- When a department head agent surfaces a decision needing CEO judgment

## Process
1. Ask CEO for: title, context, decision, alternatives considered
2. Find next ADR number in `meritgiving-ops/decision-log/`
3. Generate ADR file: `ADR-NNN-[slug].md`
4. Append to decision log index
5. Tag relevant departments in the front matter
6. If the decision changes any DEPT.md, suggest updates

## ADR template

```markdown
# ADR-NNN: [Decision title]

## Status
[Proposed | Accepted | Superseded by ADR-MMM | Deprecated]

## Date
YYYY-MM-DD

## Departments affected
[e.g., eng, data, legal]

## Context
What problem we're solving. What changed. What we considered.

## Decision
What we decided. Why this and not alternatives.

## Consequences
- What gets easier: ...
- What gets harder: ...
- What we'll measure: ...

## Alternatives considered
- **Option A:** [description]
  - Pros: ...
  - Cons: ...
  - Why not: ...
- **Option B:** [description]
  - Pros: ...
  - Cons: ...
  - Why not: ...

## Related
- ADRs: [links]
- Issues/PRs: [links]
- Risks: [risk IDs from risks.md]

## Reversibility
[Easy / Hard / Permanent] — what it would take to undo this
```

## Output
- File at `meritgiving-ops/decision-log/ADR-NNN-[slug].md`
- Update `meritgiving-ops/decision-log/INDEX.md`
- Notify affected department heads (in chat output)
- If the decision invalidates an existing ADR, mark that one "Superseded by ADR-NNN"
