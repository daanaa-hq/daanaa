# /brief [topic]

**Deep dive on any topic. Pulls full context, gives CEO catch-up in 5 min.**

## Usage examples
- `/brief partnership give-lively` — current state of Give Lively conversation
- `/brief financial-runway` — runway analysis with scenarios
- `/brief claim ein:13-1234567` — full claim history and evidence
- `/brief decision tip-jar-copy` — what we decided about tip jar disclosure
- `/brief risk fraud-claim-spoofing` — current mitigations for risk R-001
- `/brief okr o3` — full status of Objective 3

## Process
1. Identify which department(s) own the topic
2. Pull all relevant: ADRs, reports, emails (via gmail MCP), Notion docs, AirTable rows, code, etc.
3. Synthesize into structured brief
4. Highlight what's changed since last touchpoint
5. Flag what needs CEO decision

## Output format

```markdown
# Brief: [Topic]

## ONE-LINE STATUS
[Single sentence summarizing where things stand]

## HISTORY
[Timeline of key events, dates]

## CURRENT STATE
[What's happening now]

## OPEN QUESTIONS
[Decisions needed]

## RECOMMENDATIONS
[What Claude suggests]

## SOURCES
- ADR-NNN: [title]
- Report: [path]
- Email: [from gmail]
- Other: [links]
```

Adjust depth based on topic. Strategic briefs longer; tactical briefs shorter.
