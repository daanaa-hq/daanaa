# /plan-tomorrow

**Sets tomorrow's priorities at end of night session.**

## Process
1. Read today's progress
2. Look at week's OKRs and gate progress
3. Look at approval queue depth
4. Look at calendar for tomorrow
5. Suggest 3 priorities for tomorrow's 3 sessions

## Output format

```markdown
# Tomorrow's Plan — [Tomorrow's Date]

## MORNING SESSION (60 min)
- Strategic block: [topic]
- Approval queue priorities: [list]
- Top decision: [single decision needing CEO judgment]

## LUNCH SESSION (45-60 min)
- Human connection: [advisor/sponsor/user call OR build session]
- User research: [yes/no]

## NIGHT SESSION (45-60 min)
- Build/ship target: [specific deliverable]
- Weekly habit: [day-specific from operating-rhythm.md]

## SUCCESS CRITERIA
- Tomorrow is a "good day" if: [single sentence]

## OPEN APPROVALS
[List with brief context, ready for morning review]
```

Save to `meritgiving-ops/state/tomorrow.md` for morning brief context.
