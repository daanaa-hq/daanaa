# /escalate [issue]

**Immediately surface an issue to CEO. Use when something needs human judgment NOW.**

## When to use
- Anything from an "ESCALATE TO CEO" list in any DEPT.md
- Anything affecting money, legal, security, mission lock
- Conflicting direction between departments
- Tripwire from risks.md triggered
- User of MERIT reports being harmed

## Process
1. Stop other work
2. Capture: what happened, when, severity, what action is needed
3. Apply severity: P0 (NOW), P1 (today), P2 (this week)
4. P0/P1: SMS via Twilio + email + chat alert
5. P2: chat alert + email
6. Log to escalation log at `meritgiving-ops/escalations/YYYY-MM-DD-[slug].md`
7. Wait for CEO response; do not auto-resolve

## Severity guide

**P0 — Now (interrupt anything)**
- Production down
- Security breach indicators
- Legal demand
- Major press inquiry
- Mission-conflicting situation

**P1 — Today (within hours)**
- Significant inbox item from nonprofit
- Credit application response
- Advisor needs response
- Tripwire metric crossed

**P2 — This week (within days)**
- Strategic decision needed
- Risk register update needed
- Department coordination issue

## Output

```markdown
# ESCALATION — [Date Time] — [P0/P1/P2]

## ISSUE
[1-paragraph description]

## CONTEXT
[Background, what led here]

## SEVERITY
[P0/P1/P2 and why]

## RECOMMENDED ACTION
[What Claude recommends, with reasoning]

## DECISION NEEDED FROM CEO
[Specific question or approval needed]

## CONSEQUENCES OF DELAY
[What happens if CEO doesn't respond in [timeframe]]

## RELATED
- DEPT: [department triggering escalation]
- ADRs: [related decisions]
- Risks: [related risk IDs]
```
