# /ship-it

**Pre-deploy checklist. Run before ANY production deployment.**

## When to use
- Before deploying to production
- Before going public with anything

## Process

### Code/Infra checklist
- [ ] All tests pass on CI
- [ ] Type-checking clean
- [ ] Lint clean
- [ ] No console.log / print statements left
- [ ] Dependencies up to date
- [ ] No secrets in code
- [ ] Sentry source maps configured
- [ ] PostHog events tagged

### Security checklist
- [ ] HTTPS everywhere (Cloudflare verified)
- [ ] Security headers active (CSP, HSTS, X-Frame-Options)
- [ ] Rate limiting on public endpoints
- [ ] Bot protection (Turnstile) on signup/claim forms
- [ ] No exposed admin routes
- [ ] No PII in logs

### Legal/Compliance checklist (for public launch)
- [ ] ToS, Privacy Policy, Tip Disclosure, Data Credits live
- [ ] Attorney sign-off documented
- [ ] Tip jar disclosure language verbatim
- [ ] ProPublica attribution in place
- [ ] IRS data attribution in place
- [ ] security.txt at /.well-known/security.txt
- [ ] Vulnerability disclosure policy at /security

### Data checklist
- [ ] Database backup taken
- [ ] Restore tested in last 30 days
- [ ] No destructive migration without rollback plan
- [ ] Schema changes documented in ADR if non-trivial

### Operations checklist
- [ ] Uptime monitoring will catch outages
- [ ] Sentry will catch errors
- [ ] Status page accessible
- [ ] On-call (CEO + runbook) ready
- [ ] Rollback plan documented

### Mission checklist
- [ ] Does this honor mission lock?
- [ ] Does this respect privacy by architecture?
- [ ] Does this maintain equal treatment of all 501(c)(3)s?
- [ ] Is the disclosure of MERIT's limits clear?

## Output

If ALL boxes checked: "Cleared to ship. Deploy when ready."
If ANY box unchecked: list what's missing. DO NOT deploy.
If launching publicly (Gate 7): require CEO sign-off in chat.

## Special rules
- Friday after 3pm Central: ship-it returns FAIL automatically
- Saturday/Sunday: ship-it returns FAIL automatically
- Holidays: ship-it returns FAIL automatically
