# /refine-skill [name]

**Update an existing skill based on what we've learned using it.**

## When to use
- After using a skill several times and noticing inefficiencies
- When a capability gap closes via a skill but the skill could be sharper
- When external pattern (Aider, cookbook, etc.) suggests improvement
- After quarterly /model-upgrade-check identifies skill updates

## Usage
- `/refine-skill prompt-caching` — refine the prompt-caching skill
- `/refine-skill irs-bmf-ingest` — refine the BMF ingest skill

## Process

1. Read the existing skill at `merit-platform/.claude/skills/[name]/SKILL.md`
2. Read related capability gaps from `meritgiving-ops/benchmarks/capability-gaps.md`
3. Read recent agent runs that used this skill
4. Identify: what's working, what's awkward, what's slow, what's wrong
5. Propose specific changes
6. Show diff to CEO
7. On approval: update skill + bump version
8. Log update in skill's version history

## Output format

```markdown
# Skill refinement proposal: [name]

## Current pain points
- [Specific issue 1, with example]
- [Specific issue 2, with example]

## Proposed changes
- [Change 1]: rationale
- [Change 2]: rationale

## Expected improvements
- [Quantified if possible: X% faster, $Y cheaper, etc.]

## Risk of change
- [Anything that could break]

## Migration
- [How to roll out: instant / gated / staged]

## Version
- Bumping from v[N] to v[N+1]
```

## Versioning convention

Skills carry a version in their front matter:

```yaml
---
name: prompt-caching
version: 1.2.0
last_updated: 2026-05-19
status: active
---
```

- MAJOR: breaking change to how skill is used
- MINOR: new capability added
- PATCH: clarification or example improvement

## Skill registry

Maintain `meritgiving-ops/benchmarks/skills-registry.md`:
- All active skills with versions
- Last refinement date
- Usage count (from claude_calls table)
- Notes

This is how the skill library stays fresh without bloating.
