# /model-upgrade-check

**Quarterly ecosystem refresh. Run at start of each quarter.**

Audits the Claude/AI/MCP/tool ecosystem to find improvements MERIT should adopt.

## When to use
- Start of each calendar quarter (Apr 1, Jul 1, Oct 1, Jan 1)
- After any major Anthropic announcement
- After noticing a new pattern in build-in-public reading

## Process

### 1. Anthropic release scan (15 min)

Check:
- Anthropic blog: https://www.anthropic.com/news
- Claude model card updates
- API changelog: https://docs.claude.com/en/release-notes/api
- Claude Code changelog
- Pricing page for any changes

Look for:
- New models worth evaluating (cost/quality tradeoff vs. current Sonnet/Haiku)
- New API features (prompt caching enhancements, tool use improvements, batch API)
- Deprecation notices (any model strings we use being phased out?)
- New Claude Code features

### 2. MCP server registry scan (15 min)

Check:
- https://github.com/modelcontextprotocol/servers (official)
- https://github.com/modelcontextprotocol/awesome-mcp-servers (community)
- Modelscope MCP registry
- Smithery (https://smithery.ai)

Look for:
- New MCP servers we should add to `.mcp.json`
- MCP servers we use that have new versions worth upgrading
- MCP servers that displace tools we built custom

### 3. GitHub watchlist review (20 min)

Check for new patterns/releases:
- `anthropics/anthropic-cookbook` — new recipes?
- `anthropics/claude-cookbooks` — new cookbooks?
- `Aider-AI/aider` — new versions, new patterns?
- `cline/cline` — new patterns worth adopting?
- `continuedev/continue` — context management ideas?
- `getzep/graphiti` — agent memory improvements?
- `simonw/llm` — Simon's blog often has insights

For each: scan recent commits + releases + blog posts.

### 4. Cost analysis (10 min)

Pull from `claude_calls` table:
- Cost per agent this quarter vs. last
- Cache hit rate per agent
- Model distribution (Haiku/Sonnet/Opus)
- Top 10 most expensive calls
- Cost per outcome metrics

### 5. Capability gap review (10 min)

Read `meritgiving-ops/benchmarks/capability-gaps.md`:
- Gaps with 3+ occurrences → create SKILL.md tasks
- Gaps blocking critical work → P1 prioritize
- Gaps marked won't-fix → confirm still won't-fix

### 6. Synthesize (15 min)

Write quarterly memo to `meritgiving-ops/benchmarks/ecosystem-YYYY-QN.md`:

```markdown
# Ecosystem Memo — Q[N] [YEAR]

## Headline
[One-sentence summary of biggest opportunity this quarter]

## New models to evaluate
- [Model name]: [why interesting], [cost/quality vs. current], [test plan]

## New MCP servers to adopt
- [Server name]: [what it enables], [which agent], [migration plan]

## Patterns to incorporate
- [Pattern from external repo]: [where to apply], [expected savings]

## Patterns to phase out
- [Current pattern]: [why deprecating], [replacement]

## Cost optimization opportunities
- [Specific change]: [estimated savings], [implementation effort]

## Capability gaps becoming skills
- [Gap]: [SKILL.md to create], [owner]

## Risks introduced by changes
- [Risk]: [mitigation]

## Recommendations (ranked by impact)
1. [Highest impact, lowest effort]
2. [...]

## ADRs to write this quarter
- [Decision title]
- [...]
```

### 7. Decision (10 min, CEO)

Akbar reviews memo, decides which recommendations to implement this quarter. Each becomes an ADR.

## Output

- `meritgiving-ops/benchmarks/ecosystem-YYYY-QN.md` — the memo
- 1-3 ADRs in `meritgiving-ops/decision-log/`
- Updated `.mcp.json` (if MCP servers change)
- Updated agents (if patterns change)
- Updated CLAUDE.md (if conventions change)

## Frequency notes

This is QUARTERLY by default. Don't chase every new release. Discipline matters.

EXCEPTIONS for off-cycle runs:
- Major Anthropic announcement (new model class)
- Critical security disclosure in a tool we use
- Repeated capability gap blocking work

## Reference

The whole benchmarking system: `meritgiving-ops/benchmarks/SYSTEM.md`
