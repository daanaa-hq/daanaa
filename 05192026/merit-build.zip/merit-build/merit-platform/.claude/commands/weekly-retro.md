# /weekly-retro

**Friday end-of-week reflection. Captures what worked, what didn't, what to improve.**

## When to use
- Every Friday during night session
- Scores the week and updates risks/decisions

## Process
1. Pull week's metrics from PostHog, GitHub, Stripe, Sentry
2. Compare to this week's KR targets from OKRs
3. Activate strategy-lead to score the week (1-10)
4. For each dept, capture: what worked, what didn't, what to change
5. Update risks.md if any risk events occurred
6. Note any decisions made this week (link to ADRs)
7. Set Monday's priorities

## Output format

```markdown
# Week W Retro — [Date Range]

## SCORE: [N]/10

## METRICS THIS WEEK
- [KPI 1]: [value] (vs target [target])
- [KPI 2]: [value] (direction)
- [KPI 3]: [value]

## WHAT WORKED
- [items]

## WHAT DIDN'T
- [items]

## WHAT TO CHANGE
- [actions for next week]

## DECISIONS MADE
- ADR-XXX: [title]
- ADR-XXY: [title]

## RISK EVENTS
- [Any tripwires hit, escalations triggered]

## BURNOUT CHECK
- Sessions completed this week: [N]/15 (3/day x 5 days)
- Energy level (1-10): [CEO self-report]
- Sustainable pace? [Y/N]

## SET UP FOR MONDAY
- Top priority: [the ONE thing]
- Calls scheduled: [list]
- Deliverables due: [list]
```

## After running
- Output to `meritgiving-ops/briefings/weekly/YYYY-WW-retro.md`
- If burnout check is red, escalate immediately
- If score < 5, run extended retro discussion with CEO
