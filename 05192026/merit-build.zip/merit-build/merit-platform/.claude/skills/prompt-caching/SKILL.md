# Prompt Caching

**Saves ~90% on repeated context. Highest-leverage optimization in the toolbox.**

## What it is

Anthropic's prompt caching feature lets you mark stable prefixes of a prompt as cacheable. Subsequent calls with the same prefix pay 10% of normal price for cached tokens. Cache lives for 5 minutes by default.

## When to use it

ALWAYS use prompt caching when:
- The same system prompt is sent multiple times (every agent — system message is stable)
- Same large document is referenced multiple times (CLAUDE.md, DEPT.md)
- Same tool definitions used across many calls
- Few-shot examples that don't change

## How to implement

### Pattern 1: Cache the system prompt

```python
import anthropic

client = anthropic.Anthropic()

response = client.messages.create(
    model="claude-opus-4-7",
    max_tokens=1024,
    system=[
        {
            "type": "text",
            "text": "You are the eng-lead agent for MERIT...",
            "cache_control": {"type": "ephemeral"}
        }
    ],
    messages=[{"role": "user", "content": "Today's task: ..."}]
)
```

### Pattern 2: Cache big context docs (CLAUDE.md, DEPT.md)

```python
# Read large stable context once
with open("merit-platform/CLAUDE.md") as f:
    claude_md = f.read()
with open("meritgiving-ops/departments/01-product-eng/DEPT.md") as f:
    dept_md = f.read()

# Send with cache_control on the boundary
response = client.messages.create(
    model="claude-opus-4-7",
    max_tokens=1024,
    system=[
        {
            "type": "text",
            "text": f"<context>\n{claude_md}\n\n{dept_md}\n</context>",
            "cache_control": {"type": "ephemeral"}
        },
        {
            "type": "text",
            "text": "Now respond to the user's specific request."
        }
    ],
    messages=[{"role": "user", "content": user_request}]
)
```

### Pattern 3: Cache tool definitions

```python
response = client.messages.create(
    model="claude-opus-4-7",
    max_tokens=1024,
    tools=[
        {
            "name": "search_irs_bmf",
            "description": "...",
            "input_schema": {...},
            "cache_control": {"type": "ephemeral"}
        },
        # ... more tools
    ],
    messages=messages
)
```

## Cost math

Without caching (Sonnet 4 prices):
- Input: $3 / 1M tokens
- 10,000-token system prompt sent 100 times/day = 1M tokens = $3/day = $90/month

With caching:
- First call: $3 / 1M tokens (cache write, 1.25x normal)
- 99 subsequent calls: $0.30 / 1M tokens = ~$0.27 over the 99 calls
- **Total: ~$3.30/day vs $90/day = 96% savings**

For MERIT at scale (Phase 1+, multiple agents firing constantly):
- Estimated savings: $40-100/month → comfortably under $50/mo target

## Cache invalidation

Cache invalidates when:
- 5 minutes elapse without use (default TTL)
- The cached content changes by even 1 character
- The model version changes

So: cache big stable things; don't try to cache content that varies.

## What NOT to cache

- User-specific request body (varies every call)
- Current time / today's date (changes)
- Search results (vary per query)
- Anything < 1024 tokens (minimum cacheable size for Sonnet)

## Verification

After implementing, log `cached_tokens` field from API response:

```python
print(f"Input: {response.usage.input_tokens}")
print(f"Cached: {response.usage.cache_read_input_tokens}")
print(f"Cache writes: {response.usage.cache_creation_input_tokens}")
```

Update `claude_calls` table to track cached_tokens separately so cost-per-outcome metric reflects real savings.

## Where to implement first

Priority order:
1. **Worker agents** that fire on schedules (morning-briefer, inbox-shepherd, books-closer) — they have stable system prompts and run many times
2. **Department head agents** — large DEPT.md content, called repeatedly
3. **Compliance agents** (legal-reviewer) — large rule sets, fire on every PR
4. **Claude Code sessions** with CLAUDE.md context — biggest single context

## Monitoring

Once deployed:
- Track cache hit rate per agent (target > 80%)
- Alert if cache hit rate drops < 60% (something changed the stable prefix)
- Monthly review: cost reduction vs. estimate

## Reference
- Anthropic docs: https://docs.claude.com/en/docs/build-with-claude/prompt-caching
- Pricing: https://www.anthropic.com/pricing
