# Name Validation

**TASK 1 — Before LLC formation, validate name across all dimensions.**

Owner: partnerships-lead + legal-lead
Deadline: Before Gate 1 (Week 2)

Once you file the LLC, name change becomes expensive ($300-500 + new EIN scenarios + brand reset). Do this thoroughly BEFORE filing.

---

## Why now

Right now name is fluid:
- LLC not yet filed
- Domain owned but not heavily branded
- Newsletter not yet built
- Social handles not yet claimed
- No press coverage yet

After Week 2: name change costs compound. Do this NOW.

## Candidates to evaluate

**Primary:** MERIT / MeritGiving
**Backups (if conflicts found):**
- (Generate 5-10 alternatives during the audit)

## Validation dimensions

### 1. USPTO Trademark Search (Critical)

**Tool:** USPTO TESS — https://tmsearch.uspto.gov/
**Search both:**
- Exact word marks: "MERIT", "MERITGIVING", "MERIT GIVING"
- Class 36 (Financial services, including charitable fundraising)
- Class 35 (Business services)
- Class 42 (Software/SaaS)
- Class 45 (Charitable services)

**Look for:**
- Live registrations (active conflicts)
- Pending applications (potential conflicts)
- Dead marks (may indicate prior issues, less concerning)
- Common-law usage via Google search

**Document:**
- Each match found
- Class, status, owner
- Distance/similarity assessment
- Conflict likelihood (low/medium/high)

**RED FLAG:** Live registration in Class 36 or 45 with similar mark.

### 2. Texas Business Name Availability

**Tool:** Texas SOS Direct — https://direct.sos.state.tx.us/
**Check:**
- Exact name "MeritGiving LLC"
- "Merit Giving LLC"
- Common variations

**Note:** TX SOS is name-availability, not trademark protection. Even if available in TX, federal trademark can still conflict.

### 3. Domain Availability

**Current:** meritgiving.org (owned, 10 years)

**Check for backup names:**
- .org, .com, .io, .co for each backup
- Use WHOIS via https://lookup.icann.org/

**Also check:**
- Defensive registrations: should we own .com and .net even if we use .org?
- Common misspellings to capture (merrit, marit, meritt)
- Estimated cost: ~$15/yr per defensive domain

### 4. Social Media Handle Availability

**Critical platforms:**
- X/Twitter: x.com/meritgiving (check)
- Bluesky: bsky.app/profile/meritgiving.bsky.social (check)
- LinkedIn: linkedin.com/company/meritgiving (check)
- GitHub: github.com/meritgiving (you're creating this Day 1 — claim now)
- Instagram: instagram.com/meritgiving
- YouTube: youtube.com/@meritgiving
- TikTok: tiktok.com/@meritgiving (likely not used, but claim)
- Mastodon: meritgiving@mastodon.social (or similar civic-tech instance)

**Tool:** Namechk.com (https://namechk.com/) — checks 100+ platforms at once

**Document:** which platforms are available, which are taken, by whom

### 5. Search/SEO Landscape

**Google for "merit giving":**
- What ranks today?
- Are there existing brands using similar language?
- Will MERIT compete in confusing ways?

**Google Trends:**
- Is "merit giving" trending up/down/flat?
- Related searches?

**Google for "merit nonprofit":**
- Any confusion with merit-based scholarship orgs?
- Any with merit awards from foundations?

### 6. Pronunciation & memorability

- Easy to say over phone? (Yes for "MERIT", "MeritGiving" — passes)
- Easy to spell? (Yes — passes)
- Distinctive enough? (Moderate — "merit" is common English word)
- Translates well? (Yes for English-speaking markets)

### 7. Cultural/political sensitivity

- Any negative connotations?
- Any unintended associations in nonprofit sector?
- Any cause-area conflict (e.g., "Merit Pay" debates in education)?

## Process

### Week 1: Investigation (10 hours total, can split)

**Day 1-2 (you):**
- Namechk.com run on "MERIT", "MeritGiving"
- Domain WHOIS for backup names
- Google search audit

**Day 2-3 (partnerships-lead drafts):**
- USPTO TESS search with detailed write-up
- Texas SOS name availability check
- Documented findings memo

**Day 3-4 (legal-lead reviews):**
- Trademark conflict assessment
- Recommendation: PROCEED with current name / MODIFY / CHANGE

**Day 5 (CEO decides):**
- Review full memo
- Final name lock-in
- If changing: document in ADR-002

### Week 2: Lock-in actions

If staying with MERIT/MeritGiving:
- File LLC as MeritGiving LLC (Texas)
- Claim all available social handles immediately
- Register defensive domains (.com, .net at minimum)
- Begin USPTO trademark application Phase 1 (~$250-350 filing fee, attorney advised)

If changing to alternative:
- Update all internal docs
- Update meritgiving.org content (keep domain, rebrand if needed)
- Update Day 1 action plan
- New ADR documenting decision

## Backup name brainstorming criteria

If the primary name has issues, here's the criteria to generate alternatives:

**Must have:**
- 1-2 words, easy to say
- .org or .com available
- Distinctive in nonprofit sector
- No major trademark conflict
- Mission-relevant
- Memorable

**Bonus:**
- Indicates "infrastructure" or "directory" or "trust"
- Easy to make into a verb ("I MERITed it")
- Works as logo

**Categories to brainstorm:**
- Mission words: clarity, trust, fair, open
- Infrastructure words: ledger, registry, atlas
- Compound words: GiveClear, FairGive, OpenSector
- Made-up but easy: Nonprio, Verifai, Givet

## Deliverable

**File:** `meritgiving-ops/decision-log/ADR-002-name-validation.md`

Contents:
- Investigation findings (one section per dimension above)
- Recommendation
- Decision logged
- Action items (defensive registrations, USPTO application)

Plus: if name changes, full update of all other files referencing the name.

## What I (Claude) can do now

If you want, I can:
1. Generate a USPTO TESS search query strategy specific to MERIT
2. Generate a list of 20 backup name candidates with quick screening
3. Draft the trademark search write-up template
4. Generate the namechk.com result spreadsheet template

Tell me which (or all) and I'll add to this skill.

## Reference
- USPTO TESS: https://tmsearch.uspto.gov/
- USPTO trademark basics: https://www.uspto.gov/trademarks/basics
- Texas SOS Direct: https://direct.sos.state.tx.us/
- Namechk: https://namechk.com/
