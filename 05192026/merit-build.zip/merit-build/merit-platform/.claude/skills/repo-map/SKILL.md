# Repository Map

**Don't send the whole repo. Send a structured summary that helps Claude know what's there.**

Pattern adapted from Aider (https://aider.chat). Reduces token usage on coding tasks by 50%+ on large repos.

## What it is

Instead of sending Claude the full source of every file when asking about the codebase, send a compact "map" — file tree + key symbols (classes, functions) — and let Claude request specific files when needed.

## When to use

- Coding tasks in large repos (more than ~20 files)
- Questions about codebase structure
- Refactoring tasks that span multiple files
- Any time the full context would exceed ~50K tokens

## When NOT to use

- Small repos (just send everything)
- Single-file tasks (just send the file)
- Tasks where full context fits comfortably (< 30K tokens)

## How to generate the map

### Option 1: ast-grep + tree-sitter (recommended)

```bash
# Install once
pip install tree-sitter tree-sitter-languages

# Generate map
python merit-platform/scripts/generate-repo-map.py --repo . --output repo-map.md
```

The generated map looks like:

```markdown
# Repository Map

## File tree
- apps/web/
  - app/
    - (dashboard)/ceo/page.tsx
    - (dashboard)/ops/page.tsx
    - api/v1/profile/[ein]/route.ts
- packages/scoring/
  - src/index.ts
  - src/badges.ts
  - src/ntee.ts
- services/badge-engine/
  - main.py

## Key symbols

### apps/web/app/(dashboard)/ceo/page.tsx
- function CEODashboard()
- function StatusDot({ status })
- async function getDashboardData()

### packages/scoring/src/badges.ts
- function calculateBadge(org, rules)
- function badgeFreshness(org)
- type Badge
- type BadgeRule

### services/badge-engine/main.py
- class BadgeEngine
- def recalculate_all_badges()
- def recalculate_for_ein(ein)
```

### Option 2: Aider's repo-map directly

If you use Aider, it generates this automatically. We can shell out to it:

```bash
aider --show-repo-map > repo-map.md
```

## Usage pattern

```python
# In any agent that touches code

def query_codebase(question):
    # 1. Send repo map as cached context
    map_content = read_file("repo-map.md")
    
    response = client.messages.create(
        model="claude-opus-4-7",
        max_tokens=1024,
        system=[
            {
                "type": "text",
                "text": f"<repo_map>\n{map_content}\n</repo_map>",
                "cache_control": {"type": "ephemeral"}
            },
            {
                "type": "text",
                "text": "You can request specific files by name. Don't ask for files unless you need them."
            }
        ],
        tools=[read_file_tool, write_file_tool],
        messages=[{"role": "user", "content": question}]
    )
    return response
```

Claude will request only the files it actually needs.

## Token savings

For MERIT's expected codebase size (~50 files, ~10K LOC by Gate 7):
- Without map: ~80K tokens just to "see" the codebase
- With map: ~3K tokens for the map + on-demand file reads
- **Typical savings: 60-80% on coding tasks**

## Regeneration cadence

Repo map should regenerate:
- On every PR merge to main (CI step)
- Daily for the dev branch (cron)
- Before any large coding session

## Storage

Generated map lives at:
- `merit-platform/.cache/repo-map.md` (gitignored)
- Committed version at `merit-platform/docs/repo-map.md` (refreshed weekly)

## Integration with skills

Other skills can reference the repo map:
- `irs-bmf-ingest` skill cites file locations from map
- `profile-page-builder` references existing components
- `badge-scorer` knows about scoring package structure

## Reference
- Aider repo map: https://github.com/Aider-AI/aider/blob/main/aider/repomap.py
- Tree-sitter: https://tree-sitter.github.io/
