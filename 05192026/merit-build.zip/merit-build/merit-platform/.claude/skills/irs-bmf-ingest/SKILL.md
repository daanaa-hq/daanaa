# IRS BMF Ingest — Home Server Workflow

**Owner:** data-lead + Akbar
**Cadence:** Monthly, second Tuesday
**Hardware:** Home server `ecomargins` (Ubuntu), DuckDB local, sync delta to Neon Postgres

Designed around your existing infrastructure: file storage on home server, manual download cadence acceptable.

---

## Why this design

- **No 24/7 cloud ingest infrastructure to maintain** — saves $0–10/mo + complexity
- **Home server is good at batch jobs** — runs once a month, done in hours
- **DuckDB is fast for analytics** — millions of rows, no warehouse needed
- **Only delta synced to Neon** — minimal cloud egress, fast sync
- **You control the cadence** — refresh when convenient, not on a cron forcing you

## Folder structure on home server

```
/home/akbar/Meritgiving/
├── venv/                           # existing Python env
├── inbox/                          # NEW: monthly downloads land here
│   ├── 2026-05/
│   │   ├── eo1.csv                # IRS BMF Region 1 (Northeast)
│   │   ├── eo2.csv                # IRS BMF Region 2 (Mid-Atlantic)
│   │   ├── eo3.csv                # IRS BMF Region 3 (Great Lakes)
│   │   ├── eo4.csv                # IRS BMF Region 4 (Gulf Coast)
│   │   ├── eo_pr.csv              # Puerto Rico
│   │   ├── eo_xx.csv              # Other territories
│   │   ├── revoked.csv            # Auto-revocation list
│   │   └── 990n-filers.csv        # Form 990-N filer list
│   ├── 2026-06/
│   └── ...
├── data/
│   ├── duckdb/
│   │   └── merit.duckdb           # main analytics DB
│   ├── badges/                    # badge snapshots per month
│   │   └── badges-2026-05.parquet
│   └── archives/                  # historical zips
│       └── bmf-2026-05.tar.gz
├── scripts/
│   ├── ingest.sh                  # main orchestration script
│   ├── parse_bmf.py               # parse IRS files
│   ├── score_badges.py            # calculate badges
│   ├── sync_to_neon.py            # push deltas to cloud
│   └── verify.py                  # quality checks
├── backups/                       # mirror of Cloudflare R2 backups
└── logs/
    └── ingest-2026-05.log
```

## Day-of workflow (second Tuesday of each month)

### Step 1: Download files manually (~10 min)

Open the IRS Exempt Organizations BMF page:
https://www.irs.gov/charities-non-profits/exempt-organizations-business-master-file-extract-eo-bmf

Download:
- All 4 regional CSV files (eo1, eo2, eo3, eo4)
- eo_pr.csv (Puerto Rico)
- eo_xx.csv (other territories)
- Auto-revocation list: https://apps.irs.gov/app/eos/forwardToRevokeDownload.do
- 990-N filer list: https://www.irs.gov/charities-non-profits/annual-electronic-notice-form-990-n-for-small-organizations-faqs

Save all to:
```
/home/akbar/Meritgiving/inbox/2026-MM/
```

### Step 2: Run ingest script (~30-60 min, mostly hands-off)

```bash
cd /home/akbar/Meritgiving
source venv/bin/activate
./scripts/ingest.sh 2026-05
```

What happens:
1. Validates files exist and are non-empty
2. Parses BMF CSVs into normalized DuckDB tables
3. Cross-references with auto-revocation list
4. Cross-references with 990-N filer list
5. Runs quality checks (count delta vs. last month, schema validation, dupes)
6. If checks pass: creates this month's snapshot in DuckDB
7. Calculates badges based on new data
8. Computes delta vs. last month
9. Logs everything to `logs/ingest-YYYY-MM.log`

### Step 3: Review the report (~5 min)

```bash
cat /home/akbar/Meritgiving/logs/ingest-2026-05.log
```

Expected output:
```
=== IRS BMF Ingest Report — 2026-05 ===
Total EINs: 1,847,221 (prev: 1,843,902, +0.18%)
New EINs this month: 3,749
Removed EINs (revoked or merged): 430
Auto-revocations this month: 412
Reinstatements this month: 22
Status changes: 1,247
Address changes: 8,912
NTEE classification changes: 145
Schema check: PASS
Quality gates: PASS

Badges recalculated for 1,847,221 EINs.
Badge changes: 12,847 EINs had badge state change.

Ready to sync delta to Neon.
```

If checks FAIL (delta > 5%, missing files, schema change), halt and escalate.

### Step 4: Sync delta to Neon (~10 min)

```bash
./scripts/sync_to_neon.py --month 2026-05 --confirm
```

What happens:
1. Connects to Neon Postgres via DATABASE_URL
2. Pushes only CHANGED records (new, modified, removed)
3. Updates badge state for changed orgs
4. Triggers profile page revalidation via Vercel webhook
5. Posts ingest summary to ops Slack/Discord (or email)

### Step 5: Archive (~2 min)

```bash
./scripts/archive.sh 2026-05
```

Creates `archives/bmf-2026-05.tar.gz`, moves logs to permanent storage, marks month complete.

## Total time for you: ~20 min hands-on, ~60 min wall-clock

## Quality gates (auto-halt if breached)

| Check | Threshold | Action on fail |
|---|---|---|
| Total EIN count change | > 5% | HALT — escalate |
| Any region file missing | yes | HALT — re-download |
| Any region file empty | yes | HALT — re-download |
| Schema unexpected | yes | HALT — manual review |
| Duplicate EINs detected | > 100 | HALT — investigate |
| NTEE codes all valid | no | HALT — IRS data issue |
| 990-N filer count change | > 20% | WARN — review |

## Disaster recovery

If a month's ingest is bad and gets synced to Neon, rollback:

```bash
./scripts/rollback.sh --month 2026-05 --to 2026-04
```

Restores Neon to previous month's snapshot. DuckDB locally retains all history.

## Why DuckDB on home server (not cloud warehouse)

- **Free** — no Snowflake/BigQuery bills
- **Fast** — analytic queries on 1.8M rows in seconds
- **Persistent locally** — full history retained
- **DuckDB MCP server available** — Claude can query directly
- **Single file** — easy backup, easy migration
- **No vendor lock-in** — standard SQL, exports to Parquet

## Why only sync delta to Neon

- **Profile pages need fast reads** — Neon Postgres handles this
- **Most data doesn't change month-to-month** — only push deltas
- **Lower Neon costs** — stays within free tier longer
- **Faster sync** — minutes vs. hours

## What goes in Neon vs. what stays in DuckDB

**Neon (production, public-facing):**
- Current state of every EIN (latest version)
- Current badges
- Search-optimized indexes
- Claim data (Phase 1+)
- Tip jar metadata (audit)

**DuckDB (local, analytic):**
- Full historical snapshots (every month back to start)
- Badge calculations and rationales
- Cross-temporal analysis (org trends over time)
- Sector report data
- ML/research datasets

## When this changes

### Phase 1 (Month 7+)
- Add claimant self-correction layer (claimant data → Neon, never overwrites IRS)
- Add weekly delta sync (still monthly BMF refresh, but claimant changes weekly)

### Phase 2 (Month 19+)
- Possibly automate IRS download via the `data-ingest-worker` if cadence increases
- Possibly add ProPublica enrichment to home server pipeline (currently in cloud)
- Possibly migrate DuckDB to cloud if home server becomes bottleneck

For now, home server + DuckDB + manual download is the right architecture.

## What I (Claude) need from you to complete this skill

1. Confirm folder paths work for your setup
2. Tell me if you have Python venv issues, library compatibility, etc.
3. Once you create the structure, I'll generate the actual `parse_bmf.py`, `score_badges.py`, `sync_to_neon.py` scripts
4. We'll do a dry-run together for the May 2026 data when you're ready

## Reference
- IRS BMF documentation: https://www.irs.gov/charities-non-profits/exempt-organizations-business-master-file-extract-eo-bmf
- DuckDB Python: https://duckdb.org/docs/api/python/overview.html
- Neon Postgres: https://neon.tech/docs
