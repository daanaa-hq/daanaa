# Token Efficiency

**The MERIT operating discipline for keeping Claude usage cheap and sharp.**

Patterns assembled from anthropic-cookbook, Aider, Cline, and our own experience.

## The hierarchy of efficiency

In order from highest to lowest leverage:

1. **Don't call Claude unnecessarily** — use deterministic logic where possible
2. **Use prompt caching** — see `prompt-caching/SKILL.md`
3. **Use the right model** — Haiku for simple, Sonnet for complex, Opus for hard
4. **Repo maps over full files** — see `repo-map/SKILL.md`
5. **Batch processing** — when you can wait, batch is 50% cheaper
6. **Streaming for long outputs** — better UX, same cost, fail-fast
7. **Tight system prompts** — every token matters
8. **Compress conversation history** — summarize, don't accumulate

## When to use which model

| Task type | Model | Why |
|---|---|---|
| Inbox triage classification | Haiku | Fast, simple, cheap |
| Routine drafting (autoresponders) | Haiku | Template-y |
| Daily morning brief | Sonnet | Needs synthesis |
| Code review (PR-level) | Sonnet | Needs reasoning |
| Complex code generation | Sonnet (or Opus if hard) | Quality matters |
| Strategic synthesis (quarterly) | Opus | Once-in-a-quarter, worth the cost |
| Claim verification reasoning | Sonnet | High-stakes decision |
| Risk register review | Sonnet | Cross-referencing needed |

**Default for new agents: Sonnet.** Drop to Haiku only after demonstrating Haiku is sufficient. Upgrade to Opus only after demonstrating Sonnet is insufficient.

## Batch processing

For non-urgent work, use the Anthropic Batch API: 50% cheaper, 24-hour SLA.

**Good batch candidates:**
- Nightly badge recalculation explanations
- Monthly sector report drafts
- Bulk claim verification scoring (Phase 1+, when reasonable)
- Historical data backfill prompts

**Bad batch candidates:**
- Anything user-facing (response time matters)
- Daily morning brief (need it on schedule)
- Real-time inbox triage
- Claim verifications under SLA

## System prompt discipline

System prompts have inertia — they get longer over time. Audit quarterly:

- Remove example responses that aren't doing work
- Compress verbose instructions
- Move stable context into cached prefix
- Cut "polite" language ("please be helpful")
- Use structured formats (tables, JSON) over prose where applicable

**Target system prompt sizes:**
- Worker agents: < 2K tokens
- Department heads: < 5K tokens
- CLAUDE.md (Claude Code root): < 10K tokens

If a prompt grows beyond these, refactor.

## Conversation history compression

For long-running agent sessions (Claude Code, claim-verifier reviews), don't accumulate:

```python
# Bad: history grows unbounded
messages = [
    {"role": "user", "content": "Task 1"},
    {"role": "assistant", "content": "..."},
    {"role": "user", "content": "Task 2"},
    {"role": "assistant", "content": "..."},
    # ... 50 turns later, sending 100K tokens of context
]

# Good: summarize periodically
if len(messages) > 20:
    summary = compress_history(messages[:15])  # Use Haiku
    messages = [
        {"role": "user", "content": f"<previous_session>\n{summary}\n</previous_session>"}
    ] + messages[15:]
```

The `last-session.md` pattern we use in `meritgiving-ops/state/` is the file-based version of this.

## Stop generating when you have what you need

Use `stop_sequences` to halt generation early:

```python
response = client.messages.create(
    model="claude-opus-4-7",
    max_tokens=1024,
    stop_sequences=["</ANSWER>"],
    messages=[{"role": "user", "content": "...respond inside <ANSWER>...</ANSWER>"}]
)
```

Saves tokens on responses that would otherwise pad with "Let me know if you have questions!"

## Reuse outputs

Don't regenerate the same content:
- Cache morning brief structure in `/state/brief-template.md`; agent fills in deltas
- Cache standard responses (Phase 0 autoresponder verbatim)
- Cache scoring rationales by EIN; only recompute when 990 data changes

## Measuring

Every API call should log:
- Model used
- Input tokens / output tokens / cached tokens
- Cost in cents
- Agent name
- Task ID

See `benchmarks/SYSTEM.md` for the full instrumentation.

## Bad patterns to avoid

- ❌ Sending the whole `meritgiving-ops/` repo as context
- ❌ Asking Claude to "review everything we've done so far"
- ❌ Generating long responses then asking Claude to summarize them
- ❌ Using Opus when Sonnet would do
- ❌ Re-asking the same question with slight rewording
- ❌ Not using stop_sequences on structured outputs
- ❌ Letting conversation history accumulate beyond 20 turns

## Quarterly audit

Once per quarter, review:
- Top 10 most expensive agent calls (why? optimize?)
- Cache hit rates per agent (any drops?)
- Model mix (could anything move to Haiku?)
- Average system prompt size (drift over time?)
- Conversation history patterns (any unbounded growth?)

Produce report at `meritgiving-ops/benchmarks/efficiency-audit-YYYY-QN.md`.

## Reference reading

- Anthropic Cookbook: https://github.com/anthropics/anthropic-cookbook
- Claude Prompt Caching: https://docs.claude.com/en/docs/build-with-claude/prompt-caching
- Batch API: https://docs.claude.com/en/docs/build-with-claude/batch-processing
- Aider's cost optimization: https://aider.chat/docs/usage/tips.html
