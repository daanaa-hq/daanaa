# Rules: Scoring & Badge Logic

**Applies to:** `packages/scoring/**`, `services/badge-engine/**`, anything calculating nonprofit scores or badges

These paths are mission-critical and require extra discipline.

---

## Hard rules

1. **NEVER change scoring weights or thresholds without human review.**
2. **NEVER add new badge types without ADR.**
3. **NEVER use proprietary or opaque inputs.** Only IRS-public data + verified self-reported data.
4. **NEVER score on cause/religion/politics.** Equal treatment is structural.
5. **ALWAYS version scoring rule changes.** Every change creates a new version; old versions remain queryable for audit.
6. **ALWAYS document NTEE confidence.** Don't hide uncertainty in classification.
7. **ALWAYS deterministic.** Same inputs = same output. No randomness in scoring.

## Required practices

### Provenance
Every score must record:
- Input data source (IRS BMF, Form 990 via ProPublica, self-reported)
- Input data version/date
- Scoring rule version
- Calculation timestamp
- Confidence level (if applicable)

### Versioning
Scoring rule changes go through this sequence:
1. ADR documenting why
2. New version number in `packages/scoring/versions/`
3. Backward-compat: old versions retained for 12 months minimum
4. Migration plan for affected scores
5. Public errata if change corrects an error

### Inspectability
Every score on every profile must be:
- Calculable from publicly-available inputs
- Explainable in plain English
- Auditable by anyone who reads the methodology

## What we score on (Phase 0)

Categories of badges (deterministic only):
- **Filing currency:** Is the most recent 990 filing within IRS-required window?
- **NTEE category:** What's the org's primary classification (with confidence)?
- **Revenue band:** Bucketed (not exact $ from 990, which is delayed)
- **Geographic reach:** State/multi-state per IRS data
- **Public charity status:** Per IRS determination
- **Group exemption:** Parent/subordinate per IRS BMF

## What we DO NOT score on

- "Effectiveness" — outside our scope; would require value judgments
- "Efficiency ratios" — controversial (overhead myth)
- "Reputation" — subjective; opens us to litigation
- "Donor experience" — not in our scope Phase 0
- "Board quality" — not deterministically scorable

## Badge changes process

1. Strategy-lead proposes change
2. Data-lead validates against IRS data availability
3. Legal-lead confirms no inadvertent bias
4. CEO approves
5. ADR written
6. Implementation tested on staging dataset
7. Public methodology page updated
8. Errata posted if change corrects past error

## Recalculation cadence

- Monthly: full recalculation after BMF refresh (2nd Tuesday)
- Per-EIN: triggered by manual correction
- Per-EIN: triggered by claim verification update (Phase 1+)
- Never: on-the-fly per pageview (use cached scores)

## When in doubt

Read `meritgiving-ops/departments/02-data-research/DEPT.md` and `meritgiving-ops/strategy/mission-lock.md` Principle 2 (equal treatment).
