# Rules: Legal-Sensitive Code Paths

**Applies to:** `apps/web/app/(legal)/**`, `meritgiving-content/legal/**`, anything with disclosure/disclaimer pattern

These paths trigger the `legal-reviewer` agent automatically on every change.

---

## Hard rules

1. **NEVER modify ToS, Privacy Policy, Tip Disclosure, or Data Credits language without attorney sign-off.**
2. **NEVER remove the disclosure language documented in `legal-disclosure-snippets`.**
3. **NEVER remove ProPublica attribution.**
4. **NEVER remove IRS source citation.**
5. **NEVER use the word "donation" or "donate" for tips that flow to MERIT/EcoMargins.** Use "tip" or "support."
6. **NEVER imply tax-deductibility of tips to MERIT.**
7. **NEVER claim a nonprofit's tax status without citing IRS as source and date.**

## Required disclosures (verbatim)

### Tip disclosure (must appear on tip jar)
> Tips support the operations of EcoMargins Consulting LLC d/b/a MERIT (transitioning to MeritGiving LLC). Tips are not tax-deductible charitable contributions. MERIT does not handle donations to nonprofits; donate buttons link directly to each nonprofit's preferred donation page.

### ProPublica attribution (must appear where ProPublica data shown)
> Financial data sourced from IRS Form 990 filings via ProPublica Nonprofit Explorer, licensed under CC BY-NC-ND 3.0 US.

### IRS data citation (must appear on every profile page)
> Status and identification data sourced from IRS Exempt Organizations Business Master File as of [date].

### Disclaimer (must appear on profiles)
> MERIT displays public IRS data and does not verify legal authority to represent organizations. This is not legal, tax, or financial advice.

## PR workflow

When a PR touches any file under these paths:
1. `legal-reviewer` agent runs automatically
2. Reviewer diffs against approved snippets
3. Flags any new claims, removed disclosures, or modified attribution
4. Blocks merge until human review
5. If language change is significant, requires attorney review before merge

## Audit log

Every change to legal copy is logged in:
- Git history (immutable)
- `meritgiving-ops/departments/06-legal-compliance/reports/legal-copy-changes.md` (human-readable)

## When attorney review is required

ALWAYS for changes to:
- Tip disclosure language
- ToS sections on liability, dispute resolution, governing law
- Privacy policy sections on data collection, sharing, retention
- Data credits section
- Disclaimer language

NOT required for:
- Typo fixes (with diff < 5 chars and no semantic change)
- Formatting changes that don't alter meaning
- Link updates to same destination
