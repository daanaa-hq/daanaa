# Rules: Data Ingest & Storage

**Applies to:** `packages/ingest/**`, `services/data-pipeline/**`, database schema files

These paths are mission-critical for accuracy. Strict discipline required.

---

## Hard rules

1. **IRS BMF is the source of truth.** ProPublica/NCCS are enrichment only.
2. **NEVER overwrite IRS-sourced fields with claimant data.** Self-reported corrections layer as metadata, never replace.
3. **EVERY datapoint has provenance:** source, retrieved_at, last_verified, version.
4. **NEVER ingest data from non-IRS-public sources** without ADR documenting why and legal sign-off.
5. **ALWAYS attribute properly:** ProPublica per CC BY-NC-ND 3.0 US.
6. **ALWAYS handle 990-N filers explicitly.** They have less data; never pretend otherwise.
7. **NEVER share donor or claimant data with third parties.** Period.
8. **ALWAYS soft-delete.** Hard deletes only via documented data-correction process.

## Data sources (approved)

### Primary
- **IRS Exempt Organizations Business Master File (EO BMF)** — Public Domain
- **IRS Auto-Revocation List** — Public Domain
- **IRS Form 990-N Filer List** — Public Domain

### Secondary (enrichment, with attribution)
- **ProPublica Nonprofit Explorer** — CC BY-NC-ND 3.0 US
- **NCCS harmonized CORE PZ files** — public research data
- **NCCS Unified BMF** — public research data

### Tertiary (Phase 1+ with claimant consent)
- **Self-reported corrections** from verified claimants
- **Self-reported program/mission info** from verified claimants
- **PayPal Giving Fund enrollment status** via PPGF API (read-only)

## Forbidden sources

- Web scraping nonprofit-controlled sites without explicit permission
- Social media APIs (LinkedIn, etc.)
- Third-party data brokers
- Crunchbase, Pitchbook, similar for nonprofit analogs
- Email harvesting
- Donor information from any source

## Schema discipline

### Required columns for every entity
- `id` (internal, immutable)
- `ein` (IRS EIN, normalized)
- `source` (enum: irs_bmf, propublica, nccs, claimant, calculated)
- `retrieved_at` (timestamp)
- `last_verified` (timestamp)
- `version` (semver of ingest pipeline)

### Soft-delete pattern
- `deleted_at` (nullable timestamp)
- Records never hard-deleted from production
- Hard delete only via documented data-correction with legal-lead sign-off

### Migration discipline
- Every migration reviewed before production
- Rollback plan required
- Test on staging clone first
- Never migrate in production on Friday after 3pm

## Ingest cadence

- **Monthly (2nd Tuesday 2 AM Central):** Full IRS BMF refresh via `data-ingest-worker`
- **Monthly (3rd Tuesday):** Auto-revocation list refresh
- **Weekly:** ProPublica enrichment for orgs updated in BMF refresh
- **On-demand:** Self-reported corrections from claimants

## Quality gates

Every ingest run must pass:
- Total EIN count change < 5% (else halt + escalate)
- No state file missing (50 + DC required)
- All NTEE codes valid
- No duplicate EINs in primary key set
- Schema unchanged from previous run (else halt + escalate)

## Error handling

If ingest fails:
1. Halt pipeline
2. Preserve last good state in production
3. Escalate to data-lead immediately (P1)
4. Investigate root cause
5. Document in `meritgiving-ops/departments/02-data-research/reports/`
6. Resume only after green smoke tests

## Privacy by architecture

- Donor data: stored client-side or per-user only, never aggregated
- Claimant data: encrypted at rest, never used for analytics
- Anonymous engagement signals (Phase 0 follow/intent): aggregate only, no individual tracking
- Search queries: not logged with user identity
- IP addresses: 24-hour retention max, except security events
